package net.xconsulting.photon_helm;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
