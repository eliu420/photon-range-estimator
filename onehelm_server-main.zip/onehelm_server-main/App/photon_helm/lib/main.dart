import 'dart:async';

import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
//import 'dart:math';
import 'dart:convert';
import 'package:flutter/foundation.dart' show kDebugMode;

void main() {
  runApp(const HelmApp());
}

class HelmApp extends StatelessWidget {
  const HelmApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Photon Marine',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late WebSocketChannel _channel;

  // Data from web socket
  int sog = 0; // MPH
  int rpm = 0;
  var date = "";
  var time = "00:00 AM";
  int cog = 0;
  var heading = "N";
  int numFaults = 0;
  var faults = "";
  var power = 0.0; // kW
  double tripDistance = 0.0; // Miles
  var tripDuration = "0h 0m";
  int soc = 0; // %
  double energyUsed = 0.0; // kWh
  var soh = "Unknown";
  int battCycles = 0;
  int motorTemp = 0; // degC
  double totalDistance = 0; // Miles
  int minsRemaining = 0; // Minutes
  int motorTorque = 0; // % of maximum
  int packVoltage = 0; // V
  int packCurrent = 0; // A (positive is charging)
  int packTemp = 0; // degC
  int motorVoltage = 0; // V
  var gear = "Unknown"; // Neutral, Forward, Reverse
  int motorEnabled = 0;
  int nmea2000_timeout = 0; // Have we recieved CAN data from the SCU lately?
  int state_sleep = 0;
  int state_acc = 0;
  int state_ign = 0;
  int state_run = 0;
  int state_charge = 0;

  // Internal data
  String errors = "";
  bool websocketConnected = false;
  bool websocketConnecting = false;
  var websocket_uri = "";
  int updateCount = 0;
  List<Color> colorGradient = [Color(0xff2bf626), Color(0xff54ef00), Color(0xff6de800), Color(0xff80e000), Color(0xff8fd900), Color(0xff9cd100), Color(0xffa8c900), Color(0xffb2c100),
  Color(0xffbcb900), Color(0xffc4b000), Color(0xffcba700), Color(0xffd29f00), Color(0xffd89500), Color(0xffdd8c00), Color(0xffe18300), Color(0xffe57900), Color(0xffe86f00),
  Color(0xffea6500), Color(0xffeb5b00), Color(0xffeb5000), Color(0xffeb450f), Color(0xffea391d), Color(0xffe82c27), Color(0xffe51c30), Color(0xffe20438)];

  Color rpmColor = Colors.black;
  Color battColor = Colors.black;
  Color speedColor = Colors.black;

  @override
  void initState() {
    websocket_uri = 'ws://photonhelm.local:8080';
    if (kDebugMode) {
      websocket_uri = 'ws://192.168.1.207:8080';
    }

    // TODO: Add connect retries
    websocketConnect();
  }

  Timer scheduleTimeout([int milliseconds = 10000]) => Timer.periodic(Duration(milliseconds: milliseconds), handleTimeout);

  void handleTimeout(Timer timer) {
    if (websocketConnected == false && websocketConnecting == false) {
      websocketConnect();
    }
  }

  void websocketConnect() {
    websocketConnected = false;
    websocketConnecting = true;

    try {
      setState(() {
        errors = "Websocket connecting...";
      });

      _channel = WebSocketChannel.connect(
        Uri.parse(websocket_uri),
      );

      _channel.stream.listen((data) {
        Map<String, dynamic> decodedData = jsonDecode(data);

        setState(() {
          websocketConnected = true;
          websocketConnecting = false;
          updateCount += 1;
          errors = "Web socket connected";

          if (decodedData['sog'] != null) {
            sog = decodedData['sog'].abs();
          }

          if (decodedData['rpm'] != null) {
            rpm = decodedData['rpm'].abs();
          }

          if (decodedData['date'] != null) {
            date = decodedData['date'];
          }

          if (decodedData['time'] != null) {
            time = decodedData['time'];
          }

          if (decodedData['cog'] != null) {
            cog = decodedData['cog'];
          }

          if (decodedData['heading'] != null) {
            heading = decodedData['heading'];
          }

          if (decodedData['numFaults'] != null) {
            numFaults = decodedData['numFaults'];
          }

          if (decodedData['faults'] != null) {
            faults = decodedData['faults'];
          }

          if (decodedData['power'] != null) {
            power = decodedData['power'].abs();
            //power = power.abs();
          }

          if (decodedData['tripDistance'] != null) {
            tripDistance = decodedData['tripDistance'];
          }

          if (decodedData['soc'] != null) {
            soc = decodedData['soc'];
          }

          if (decodedData['energyUsed'] != null) {
            energyUsed = decodedData['energyUsed'].abs();
          }

          if (decodedData['battCycles'] != null) {
            battCycles = decodedData['battCycles'];
          }

          if (decodedData['motorTemp'] != null) {
            motorTemp = decodedData['motorTemp'];
          }

          if (decodedData['totalDistance'] != null) {
            totalDistance = decodedData['totalDistance'];
          }

          if (decodedData['minsRemaining'] != null) {
            minsRemaining = decodedData['minsRemaining'];
          }

          if (decodedData['motorTorquePct'] != null) {
            motorTorque = decodedData['motorTorquePct'];
          }

          if (decodedData['packVoltage'] != null) {
            packVoltage = decodedData['packVoltage'];
          }

          if (decodedData['packCurrent'] != null) {
            packCurrent = decodedData['packCurrent'];
          }

          if (decodedData['packTemp'] != null) {
            packTemp = decodedData['packTemp'];
          }

          if (decodedData['tripDuration'] != null && decodedData['tripDuration'] > 0) {
            int hours = decodedData['tripDuration'] ~/ 3600;
            int mins = decodedData['tripDuration'] ~/ 60;

            tripDuration =
                hours.toStringAsFixed(0) + 'h ' + mins.toStringAsFixed(0) + 'm';
          }

          if (decodedData['soh'] > 90) {
            soh = "Good";
          }
          else if (decodedData['soh'] > 75) {
            soh = "Fair";
          }
          else {
            soh = "Poor";
          }

          if (decodedData['motorVoltage'] != null) {
            motorVoltage = decodedData['motorVoltage'];
          }

          if (decodedData['gear'] != null) {
            gear = decodedData['gear'];
          }

          if (decodedData['motorEnabled'] != null) {
            motorEnabled = decodedData['motorEnabled'];
          }

          if (decodedData['nmea2000_timeout'] != null) {
            nmea2000_timeout = decodedData['nmea2000_timeout'];
          }

          if (decodedData['state_sleep'] != null) {
            state_sleep = decodedData['state_sleep'];
          }
          if (decodedData['state_acc'] != null) {
            state_acc = decodedData['state_acc'];
          }
          if (decodedData['state_ign'] != null) {
            state_ign = decodedData['state_ign'];
          }
          if (decodedData['state_run'] != null) {
            state_run = decodedData['state_run'];
          }
          if (decodedData['state_charge'] != null) {
            state_charge = decodedData['state_charge'];
          }
        });
      }, onError: (error) {
        setState(() {
          errors = "Web socket error";
        });
      });
    } catch (e) {
      setState(() {
        errors = "Failed to connect to web socket";
        websocketConnected = false;
        websocketConnecting = false;
      });
    }
  }

  Widget topBar() {
    var status = "OFF";

    if (state_run == 1) {
      status = "RUN";
    } else if (state_charge == 1) {
      status = "CHARGE";
    } else if (state_ign == 1) {
      status = "IGNITION";
    } else if (state_acc == 1) {
      status = "ACCESSORY";
    }
    /*
    if (packVoltage > 50 && motorEnabled == 1) {
       status = "RUN";
    } else if (packVoltage > 50 && packCurrent < -1) {
       status = "CHARGE";
    } else if (packVoltage > 50 && motorEnabled == 0) {
       status = "IGNITION";
    } else if (state_acc == 1) {
       status = "ACCESSORY";
     }
    */

    return Container(
      height: 80,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        color: Color(0xFF2a2727),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 90.0, top: 20.0, bottom: 10.0, right: 30.0),
            child: Column(
              children: [
                Text("SYSTEM STATUS", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                SizedBox(height: 5),
                Text(status, style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                SizedBox(height: 5),
                Text(numFaults.toString()+" Alerts", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold))
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                Text("OUTPUT", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                SizedBox(height: 5),
                Text(power.toStringAsFixed(2)+" kW", style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold))
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                Text("MOTOR GEAR", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                SizedBox(height: 5),
                Text(gear.toString(), style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold))
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                Text("TRIP DISTANCE", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                SizedBox(height: 5),
                Text(tripDistance.toStringAsFixed(2)+" mi", style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold))
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 90.0, top: 20.0, bottom: 20.0, left: 30.0),
            child: Column(
              children: [
                Text("TRIP TIME", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                SizedBox(height: 5),
                Text(tripDuration, style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold))
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget speedGauge() {
    int indexSpeed = sog - 10;
    if (sog < 10) {
      speedColor = colorGradient[0];
    }
    else if (sog >= 10 && sog < 35) {
      speedColor = colorGradient[indexSpeed];
    }
    else {
      speedColor = colorGradient[24];
    }
    return Container(
      //width: 700, // TODO: don't like static value here
      child: SfRadialGauge(
          axes: <RadialAxis>[
            RadialAxis(
                startAngle: 120,
                endAngle: 480,
                minimum: 0,
                maximum: 100,
                //centerY: .30,
                //radiusFactor: 1.8,
                canScaleToFit: true,
                ranges: <GaugeRange>[
                  GaugeRange(
                      startValue: 0,
                      endValue: 100,
                      startWidth: 30,
                      endWidth: 30,
                      color:Color(0xbf6f6868),
                      rangeOffset: -5
                  ),
                ],
                pointers: <GaugePointer>[
                  RangePointer(
                    value: sog.toDouble(),
                    width: 20,
                    cornerStyle: CornerStyle.bothCurve,
                    color: Colors.greenAccent,
                  )
                ],
                annotations: <GaugeAnnotation>[
                  GaugeAnnotation(
                    widget: Container(
                      height: 250,
                      child: Column(
                        children:[
                          Text(sog.toStringAsFixed(1), style: TextStyle(color: Colors.white, fontSize: 90, fontWeight: FontWeight.bold)),
                          SizedBox(height: 10),
                          Text("KNOTS", style: TextStyle(color: Colors.grey, fontSize: 32, fontWeight: FontWeight.normal)),
                          SizedBox(height: 10),
                          Image(image: AssetImage('photon_icon.png')),
                        ]
                      ),
                    ),
                    angle: 90,
                    positionFactor: 0
                  )
                ]
            )
          ]
      ),
    );
  }

  Widget rpmGauge() {
    int indexRpm = ((rpm-2500) ~/ 100);
    if (rpm > 2500) {
      if (indexRpm < 0)
        indexRpm = 0;
      if (indexRpm > 24)
        indexRpm = 24;
      rpmColor = colorGradient[indexRpm];
    }
    else {
      rpmColor = colorGradient[0];
    }

    return Container(
      //width: 450,
      child: SfRadialGauge(
        axes: <RadialAxis>[
          RadialAxis(
              //centerY: .85,
              //centerX: .25,
              startAngle: 120,
              endAngle: 300,
              minimum: 0,
              maximum: 5000,
              ranges: <GaugeRange>[
                GaugeRange(
                  startValue: 0,
                  endValue: 5000,
                  startWidth: 30,
                  endWidth: 30,
                  color: Color(0xbf6f6868),
                  rangeOffset: -5,
                  /*gradient: const SweepGradient(
                    //radius: 0.2,
                    colors: [Color(0xFF2a6082), Color(0xFF2f6b91)],
                    stops: [0.2, 0.5]
                  )*/
                ),
              ],
              pointers: <GaugePointer>[
                RangePointer(
                  value: rpm.toDouble(),
                  width: 20,
                  cornerStyle: CornerStyle.bothCurve,
                  color: Colors.red,
                )
              ],
              annotations: <GaugeAnnotation>[
                GaugeAnnotation(widget:
                Container(
                  height: 250,
                  child: Column(
                    children:[
                      Text(rpm.toString(), style: TextStyle(color: Colors.white, fontSize: 90, fontWeight: FontWeight.bold)),
                      Text("RPM", style: TextStyle(color: Colors.grey, fontSize: 32, fontWeight: FontWeight.normal)),
                      Image(image: AssetImage('leaf.png')),
                    ]
                  ),
                ),
                    angle: 90,
                    positionFactor: 0
                )
              ]
          )
        ]
      )
    );
  }

  Widget battGauge() {
    int indexBatt = 0;
    if (soc > 75){
      battColor = colorGradient[0];
    }
    else if (soc <= 75 && soc > 25){
      indexBatt = (soc - 25) ~/ 2;
      battColor = colorGradient[(24-indexBatt)];
    }
    else{
      battColor = colorGradient[24];
    }

    return Container(
      //width: 450,
      child: SfRadialGauge(
        axes: <RadialAxis>[
          RadialAxis(
              //centerY: .85,
              //centerX: .75,
              //radiusFactor: 1.5,
              minimum: 0,
              maximum: 100,
              startAngle: 240,
              endAngle: 60,
              isInversed: true,
              ranges: <GaugeRange>[
                GaugeRange(
                  startValue: 0,
                  endValue: 100,
                  startWidth: 30,
                  endWidth: 30,
                  rangeOffset: -5,
                  color:Color(0xbf6f6868)
                ),
              ],
              pointers: <GaugePointer>[
                RangePointer(
                  value: soc.toDouble(),
                  width: 20,
                  cornerStyle: CornerStyle.bothCurve,
                  color: battColor,
                )
              ],
              annotations: <GaugeAnnotation>[
                GaugeAnnotation(widget:
                  Container(
                    height: 250,
                    child: Column(
                      children:[
                        Text("BATTERY LEVEL", style: TextStyle(color: Colors.grey, fontSize: 32, fontWeight: FontWeight.normal)),
                        //SizedBox(height: 10),
                        Text(soc.toStringAsFixed(0)+"%", style: TextStyle(color: Colors.white, fontSize: 60, fontWeight: FontWeight.bold)),
                        SizedBox(height: 5),
                        Text("ENERGY USED", style: TextStyle(color: Colors.grey, fontSize: 24, fontWeight: FontWeight.normal)),
                        SizedBox(height: 10),
                        Text(energyUsed.toStringAsFixed(2)+" kWh", style: TextStyle(color: Colors.white, fontSize: 35, fontWeight: FontWeight.bold)),
                      ]
                    ),
                  ),
                    angle: 90,
                    positionFactor: 0
                )
              ]
          )
        ]
      )
    );
  }

  Widget bottomBar() {
    return Container(
      //margin: EdgeInsets.all(30.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        color: Color(0xFF2a2727),
      ),
      child:
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 90.0, top: 20.0, bottom: 20.0, right: 30.0),
              child: Column(
                children: [
                  Text("BATTERY HEALTH", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                  SizedBox(height: 15),
                  Text(soh, style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Text("BATTERY CYCLES", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                  SizedBox(height: 15),
                  Text(battCycles.toString(), style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Text("MOTOR TEMP", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                  SizedBox(height: 15),
                  Text(motorTemp.toStringAsFixed(0)+"° C", style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Text("BATTERY TEMP", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                  SizedBox(height: 15),
                  Text(packTemp.toStringAsFixed(0)+"° C", style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 90.0, top: 20.0, bottom: 20.0, left: 30.0),
              child: Column(
                children: [
                  Text("TOTAL DISTANCE", style: TextStyle(color: Colors.grey, fontSize: 28, fontWeight: FontWeight.normal)),
                  SizedBox(height: 15),
                  Text(totalDistance.toStringAsFixed(2)+" mi", style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ],
        ),
    );
  }

  @override
  Widget build(BuildContext context) {
      return Scaffold(
        backgroundColor: Colors.black,
        //backgroundColor: Color(0xFF171414),
        body: Center(
          child: Column(
            children: [
              Expanded(
                flex: 5,
                child: Row(
                  //mainAxisAlignment: MainAxisAlignment.spaceBetween ,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 30.0, right: 10.0, top: 10.0, bottom: 10.0),
                      child: Text(time, style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.normal)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Text("75°F", style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.normal)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        children: [
                          Icon(Icons.flag, color: Colors.white, size: 24.0,),
                          Text(cog.toStringAsFixed(0), style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.normal))
                        ]
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Icon(websocketConnected ? Icons.signal_wifi_4_bar : Icons.signal_wifi_bad, color: Colors.white, size: 30.0,),
                    ),
                  ],

                ),
              ),

              Expanded(
                flex: 15,
                child: topBar()
              ),
              Expanded(
                flex: 60,
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                          Container(child: rpmGauge(), width: 450, transform: Matrix4.translationValues(75.0, 45.0, 0.0)),
                          Container(child: speedGauge(), width: 550, transform: Matrix4.translationValues(10.0, 0.0, 0.0)),
                          Container(child: battGauge(), width: 450, transform: Matrix4.translationValues(-25.0, 45.0, 0.0)),
                  ],
                ),
              ),
              Expanded(
                flex: 15,
                child: bottomBar()
              ),
              /*
              Expanded(
                flex:5,
                child: Row(
                  children: [
                    SizedBox(width: 20),
                    Text(updateCount.toString(), style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.normal)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(errors, style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.normal)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(motorVoltage.toStringAsFixed(0), style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.normal)),
                    ),
                    ElevatedButton(
                      child: const Text('Admin'),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const AdminPage()),
                        );
                      },
                    ),
                  ],
                ),
              )
              */
            ],
          ),
        )
    );
  }



  @override
  void dispose() {
    _channel.sink.close();
    super.dispose();
  }
}

class AdminPage extends StatelessWidget {
  const AdminPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Column(
              children: [
                Image(image: AssetImage('clark.jpg')),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Go back!'),
                ),
              ],
          )
      )
    );
  }
}


