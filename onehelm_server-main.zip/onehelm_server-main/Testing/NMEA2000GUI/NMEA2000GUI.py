import time
import sys
import os
import ctypes
import traceback
import math
import configparser

import can
import cantools

from PyQt5.QtWidgets import QWidget
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtWidgets import QFrame
from PyQt5.QtWidgets import QBoxLayout
from PyQt5.QtWidgets import QGridLayout
from PyQt5.QtWidgets import QLabel
from PyQt5.QtWidgets import QComboBox
from PyQt5.QtWidgets import QGroupBox
from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtWidgets import QCheckBox
from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import QTableWidget
from PyQt5.QtWidgets import QTableWidgetItem
from PyQt5.QtWidgets import QAbstractItemView
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtWidgets import QHeaderView
from PyQt5.QtWidgets import QSizePolicy
from PyQt5.QtWidgets import QListWidget
from PyQt5.QtWidgets import QListWidgetItem
from PyQt5.QtCore import Qt
from PyQt5.QtCore import QThread
from PyQt5.QtCore import QIODevice
from PyQt5.QtCore import QWaitCondition
from PyQt5.QtCore import QMutex
from PyQt5.QtCore import QByteArray
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtCore import pyqtSignal
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QColor
from PyQt5.QtGui import QPalette
from PyQt5.QtGui import QIcon

class CANThread(QThread):
    can_recv_signal = pyqtSignal(int,int,int,int,int,int,int,int,int,int)
    send_status_signal = pyqtSignal(int)

    CAN_STATUS_CONNECTED = 0
    CAN_STATUS_FAILED = 1
    CAN_STATUS_DISCONNECTED = 2
    CAN_STATUS_BUS_ERROR = 3
    CAN_STATUS_BUS_OK = 4
    
    def __init__(self):
        QThread.__init__(self)
        self.bus = None
        self.xmit_errors = 0

    def connect(self, _type, _channel, _bitrate):
        try:
            self.bus = can.ThreadSafeBus(bustype=_type, channel=_channel, bitrate=_bitrate)
            print("Connected to CAN device")
            self.send_status_signal.emit(self.CAN_STATUS_CONNECTED)
        except:
            self.bus = None
            print("Failed to find CAN device")
            traceback.print_exc()
            self.send_status_signal.emit(self.CAN_STATUS_FAILED)

    def disconnect(self):
        try:
            self.bus.shutdown()
            self.send_status_signal.emit(self.CAN_STATUS_DISCONNECTED)
        except:
            print("Failed to shut down bus")
        self.bus = None

    def reset(self):
        try:
            self.bus.reset()
        except:
            print("Failed to reset bus")

    # run method gets called when we start the thread
    def run(self):
        while True:
            if self.bus != None:
                for msg in self.bus:
                    data = [0,0,0,0,0,0,0,0]
                    for i in range(0,msg.dlc):
                        data[i] = msg.data[i]
                    self.can_recv_signal.emit(msg.arbitration_id, msg.dlc, data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7])
            else:
                time.sleep(0.1)

    @pyqtSlot(int,int,int,int,int,int,int,int,int,int)
    def sendCmdMessage(self, can_id, data_len, d0,d1,d2,d3,d4,d5,d6,d7):
        msg_data = [d0,d1,d2,d3,d4,d5,d6,d7]

        msg = can.Message(arbitration_id=can_id, is_extended_id=True, data=msg_data)
        if self.bus != None:
            try:
                self.bus.send(msg, 0.001)
                if self.xmit_errors > 0:
                    self.xmit_errors -= 1
            except:
                self.xmit_errors += 1

            if self.xmit_errors > 20:
                self.send_status_signal.emit(self.CAN_STATUS_BUS_ERROR)
            if self.xmit_errors == 0:
                self.send_status_signal.emit(self.CAN_STATUS_BUS_OK)

class NMEA2000GUI(QMainWindow):
    send_cmd_signal = pyqtSignal(int,int,int,int,int,int,int,int,int,int)

    PCAN_STATE_CONNECTED = 1
    PCAN_STATE_DISCONNECTED = 0

    bustypes = ["KVaser","PCAN","Ixxat"]
    bitrates = ["125k","250k","500k","1M"]
    
    def __init__(self):
        QWidget.__init__(self, flags=Qt.Widget)

        self.pcan_state = self.PCAN_STATE_DISCONNECTED

        self.ini_filename = 'nmea2000_gui.ini'
        self.config = configparser.ConfigParser()
        
        self.dbc = cantools.database.load_file("./photon_nmea2000.dbc", database_format='dbc', cache_dir='nmea2000')

        self.nmea2000_message_seq = 0

        self.loadPreferences()
        self.init_widget()

        self.can_thread = CANThread()
        self.send_cmd_signal.connect(self.can_thread.sendCmdMessage)
        self.can_thread.can_recv_signal.connect(self.handleCANMessage)
        self.can_thread.send_status_signal.connect(self.handleCANStatus)
        self.can_thread.start()

        timer = QTimer(self) 
        timer.timeout.connect(self.sendCANMessages)
        timer.start(120)
        
    def init_widget(self):
        self.setWindowTitle("NMEA 2000 GUI v0.1")
        self.statusBar().showMessage('OK')
        main_layout = QBoxLayout(QBoxLayout.LeftToRight, parent=self)

        main_widget = QWidget()
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

        system_grid_frame = QFrame(self)
        system_grid_frame.setFrameShape(QFrame.StyledPanel)
        system_grid_frame.setFrameShadow(QFrame.Raised)
        system_grid = QGridLayout(system_grid_frame)

        ''' CAN / Serial config '''

        self.combo_bustype = QComboBox()
        i=0
        for bustype in self.bustypes:
            self.combo_bustype.addItem(bustype)
            if bustype == self.can_adapter:
                self.combo_bustype.setCurrentIndex(i)
            i += 1

        self.combo_rate = QComboBox()
        i=0
        for bitrate in self.bitrates:
            self.combo_rate.addItem(bitrate)
            if bitrate == self.can_baud:
                self.combo_rate.setCurrentIndex(i)
            i += 1

        self.btn_connect = QPushButton("Connect")
        self.btn_connect.clicked.connect(self.connect)

        self.lbl_can_status = QLabel("Not connected")

        row = 0
        system_grid.addWidget(self.combo_bustype, row, 0)
        system_grid.addWidget(self.combo_rate, row, 1)
        system_grid.addWidget(self.btn_connect, row, 2)
        row += 1

        system_grid.addWidget(self.lbl_can_status, row, 0, 1, 3)
        row += 1

        ''' System Data '''
                                       
        ''' Main layout '''

        main_layout.addWidget(system_grid_frame)

    def connect(self):
        bustype = self.combo_bustype.currentText()
        baud = self.combo_rate.currentText()

        self.can_rate = baud
        self.can_adapter = bustype

        self.config["bench"]["CANAdaptor"] = self.can_adapter
        self.config["bench"]["CANBAUD"] = self.can_rate
        
        self.savePreferences()
        
        if baud == "125k":
            bitrate = 125000
        elif baud == "250k":
            bitrate = 250000
        elif baud == "500k":
            bitrate = 500000
        elif baud == "1M":
            bitrate = 1000000

        if bustype == 'PCAN':
            bustype = 'pcan'
            interface = 'PCAN_USBBUS1'
        elif bustype == 'KVaser':
            bustype = 'kvaser'
            interface = '0'
        elif bustype == 'IXXAT':
            bustype = 'ixxat'
            interface = '0'

        if self.pcan_state == self.PCAN_STATE_DISCONNECTED:
            self.lbl_can_status.setText("Connecting...")
            self.can_thread.connect(bustype, interface, bitrate)
        elif self.pcan_state == self.PCAN_STATE_CONNECTED:
            self.lbl_can_status.setText("Disconnecting...")
            self.can_thread.disconnect()

    def sendCANMessages(self):
        #120ms
        self.sendMessage()

    def sendMessage(self):
        frame = {}

        frame["percent_engine_torque"] = 20
        frame["percent_engine_load"] = 30
        frame["warning_level2"] = 0
        frame["warning_level1"] = 0
        frame["sensor_malfunction"] = 0
        frame["secondary_throttle"] = 0
        frame["power_reduction"] = 0
        frame["neutral_start_protect"] = 0
        frame["maint_needed"] = 0
        frame["engine_shutting_down"] = 0
        frame["engine_comm_error"] = 0
        frame["water_in_fuel"] = 0
        frame["water_flow"] = 0
        frame["throttle_position_sensor"] = 0
        frame["rev_limit_exceeded"] = 0
        frame["preheat_indicator"] = 0
        frame["over_temp"] = 0
        frame["low_system_voltage"] = 0
        frame["low_oil_pressure"] = 0
        frame["low_oil_level"] = 0
        frame["low_fuel_pressure"] = 0
        frame["low_coolant_level"] = 0
        frame["high_boost_pressure"] = 0
        frame["engine_emergency_stop"] = 0
        frame["egr_system"] = 0
        frame["check_engine"] = 0
        frame["charge_indicator"] = 0
        frame["total_engine_hours"] = 1000
        frame["not_available"] = 0xFF
        frame["fuel_rate"] = 0.1
        frame["fuel_pressure"] = 60
        frame["engine_coolant_pressure"] = 50
        frame["engine_temp"] = 350
        frame["engine_oil_temp"] = 350
        frame["engine_oil_pressure"] = 7000
        frame["alternator_potential"] = 14
        frame["engine_instance"] = 0

        try:
            full_data = self.dbc.encode_message(0x9F201FE, frame, scaling=True, padding=False, strict=True)
            data = {}

            if self.nmea2000_message_seq == 0:
                data[0] = 0xE0
                data[1] = 26
                data[2] = full_data[0]
                data[3] = full_data[1]
                data[4] = full_data[2]
                data[5] = full_data[3]
                data[6] = full_data[4]
                data[7] = full_data[5]
            elif self.nmea2000_message_seq == 1:
                data[0] = 0xE1
                data[1] = full_data[6]
                data[2] = full_data[7]
                data[3] = full_data[8]
                data[4] = full_data[9]
                data[5] = full_data[10]
                data[6] = full_data[11]
                data[7] = full_data[12]
            elif self.nmea2000_message_seq == 2:
                data[0] = 0xE2
                data[1] = full_data[13]
                data[2] = full_data[14]
                data[3] = full_data[15]
                data[4] = full_data[16]
                data[5] = full_data[17]
                data[6] = full_data[18]
                data[7] = full_data[19]
            elif self.nmea2000_message_seq == 3:
                data[0] = 0xE3
                data[1] = full_data[20]
                data[2] = full_data[21]
                data[3] = full_data[22]
                data[4] = full_data[23]
                data[5] = full_data[24]
                data[6] = full_data[25]
                data[7] = 0xFF
            
        except:
            self.handleExcept()
            return
            
        try:
            self.send_cmd_signal.emit(0x9F20103,8,data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7])
        except:
            self.handleExcept()
            return

        self.nmea2000_message_seq += 1
        if self.nmea2000_message_seq > 3:
            self.nmea2000_message_seq = 0
        
    @pyqtSlot(int)
    def handleCANStatus(self, status):
        if status == self.can_thread.CAN_STATUS_FAILED:
            self.lbl_can_status.setText("Failed to find CAN device")
            self.pcan_state = self.PCAN_STATE_DISCONNECTED
            self.combo_bustype.setEnabled(True)
            self.combo_rate.setEnabled(True)
            
        elif status == self.can_thread.CAN_STATUS_CONNECTED:
            self.lbl_can_status.setText("CAN device connected")
            self.btn_connect.setText("Disconnect")
            self.pcan_state = self.PCAN_STATE_CONNECTED
            self.combo_bustype.setEnabled(False)
            self.combo_rate.setEnabled(False)

        elif status == self.can_thread.CAN_STATUS_DISCONNECTED:
            self.lbl_can_status.setText("Disconnected")
            self.btn_connect.setText("Connect")
            self.pcan_state = self.PCAN_STATE_DISCONNECTED
            self.combo_bustype.setEnabled(True)
            self.combo_rate.setEnabled(True)

        elif status == self.can_thread.CAN_STATUS_BUS_ERROR:
            self.lbl_can_status.setText("Failed to send CAN message, check BUS")

        elif status == self.can_thread.CAN_STATUS_BUS_OK:
            self.lbl_can_status.setText("CAN device connected")

    @pyqtSlot(int,int,int,int,int,int,int,int,int,int)
    def handleCANMessage(self, can_id, data_len, d0,d1,d2,d3,d4,d5,d6,d7):
        data = bytearray([d0,d1,d2,d3,d4,d5,d6,d7])

        try:
            pass
        except:
            self.handleExcept()

    def loadPreferences(self):
        inifile = self.config.read(self.ini_filename)

        if len(inifile) == 0:
            self.config['bench'] = {
                'CANAdaptor': 'KVaser',
                'CANBAUD': '500k'
                }
            self.savePreferences()

        self.can_adapter = self.config['bench'].get('CANAdaptor', 'KVaser')
        self.can_baud = self.config['bench'].get('CANBAUD', '500k')

    def savePreferences(self):
        with open(self.ini_filename, 'w') as configfile:
            self.config.write(configfile)
            configfile.close()

    def handleExcept(self):
        traceback.print_exc()
        self.logError(traceback.format_exc())
        time.sleep(1)

    def logError(self, msg):
        self.statusBar().showMessage(msg)

    def closeEvent(self, event):
        print("Closing app")
        self.can_thread.disconnect()
        self.can_thread.quit()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon('icon.ico'))
    
    app.setStyle('Fusion')
    qp = QPalette()
    qp.setColor(QPalette.ButtonText, Qt.white)
    qp.setColor(QPalette.Window, Qt.gray)
    qp.setColor(QPalette.Button, Qt.black)
    #app.setPalette(qp)

    
    excepthook = sys.excepthook
    sys.excepthook = lambda t, val, tb: excepthook(t, val, tb)
    gui = NMEA2000GUI()
    gui.setGeometry(50, 50, 900, 300)
    gui.show()

    app.exec_()
