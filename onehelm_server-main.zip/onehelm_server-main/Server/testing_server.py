# This is a testing script to run non-true data through to 
# OpenHelm system so as to test graphics, comms, and response
# time within the system. The MultiFramePacket class is imported
# from the nmea2000_server.py script and should be updated back 
# and forth as necessary. 

# Continuous
# 'rpm': 0,               Dynamically updating 1/sec
# 'sog': 25,              Knot, Dynamically updating 1/sec
# 'cog': 0,               Direction in degrees?, Dynamically updating 1/sec
# 'date': "12:34 PM",     Date, Updating 1/day
# 'time': "12:34 PM",     Time, Updating 1/min
# 'heading': "N",         Direction, Updating 1/min
# 'numFaults': 0,         # of faults, Updating 1/min
# 'faults': "",           Faults, Updating 1/min
# 'power': 0.0,           Power in kW left, Updating 1/sec
# 'tripDistance': 0.0,    single trip distance (some number less than total, Updating 1/sec
# 'totalDistance': 0,     Total distance traveled (what is our total distance allowance?, Updating 1/sec
# 'tripDuration': 0,      Duration of trip, Updating 1/sec
# 'energyUsed': 0.0,      Power used, Updating 1/sec
# 'soc': 0,               State of Charge (%), Updating 1/min
# 'soh': 0,               State of Health (%), Updating 1/min
# 'minsRemaining': 0,     Minutes of charge left, Updating 1/min
# 'battCycles': 0,        # of full battery cycles, Updating 1/hour
# 'motorTemp': 0,         Motor Temp (Celcius), Updating 1/min
# 'motorTorquePct': 0,    % of Torgue used, Updating 1/min
# 'packVoltage': 0,       Voltage, Updating 1/sec
# 'packCurrent': 0,       Current, Updating 1/sec


from datetime import datetime
import configparser
import asyncio
import json
import traceback
import nmea2000_server

# external deps
import websockets   # websockets







if __name__ == '__main__':
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        server = NMEA2KServer()
        server.start_server(loop)

        loop.run_forever()
    except KeyboardInterrupt:
        pass