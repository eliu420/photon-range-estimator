from datetime import datetime
import configparser
import asyncio
import json
import traceback
import socket
import fcntl
import struct
import time
import configparser

# external deps
import websockets   # websockets
import can          # python-can
import cantools     # cantools

NAME = "server"

class NMEA2KServer():

    def __init__(self):
        self.data = {
            'sog': 0,               # Knot, COG SOG Rapid Update
            'rpm': 0,               # RPM, Engine Parameters Rapid Update
            'date': "12:34 PM",     # GNSS Position Data
            'time': "12:34 PM",     # GNSS Position Data
            'cog': 0,               # Deg, COG SOG Rapid Update
            'heading': "N",         # calculated
            'numFaults': 0,         # TODO
            'faults': "",           # TODO
            'power': 0.0,           # kW, calculated
            'tripDistance': 0.0,    # miles
            'soc': 0,               # %, DC Detailed Status
            'energyUsed': 0.0,      # kWh
            'battCycles': 0,        # stored locally
            'motorTemp': 0,         # degC, Engine Parameters Dynamic
            'totalDistance': 0,     # miles
            'minsRemaining': 0,     # mins, DC Detailed Status
            'tripDuration': 0,      # mins
            'motorTorquePct': 0,    # %, Engine Parameters Dynamic
            'packVoltage': 0,       # V, DC Voltage Current
            'packCurrent': 0.0,     # A, DC Voltage Current
            'packTemp': 0,          # degC, Battery Status
            'soh': 0,               # %, DC Detailed Status
            'totalMotorHours': 0.0, # hours motor rpm > 0
            'motorVoltage': 0,      # V, Engine Parameters Dynamic (alternator potential /10)
            'gear': "Unknown",      # Neutral, Forward, Reverse
            'motorEnabled': 0,      # 0: disabled, 1: enabled
            'nmea2000_timeout': 0,  # 0: NMEA2000 data received (EV), 1: timeout
            'state_sleep': 0,
            'state_acc': 0,
            'state_ign': 0,
            'state_run': 0,
            'state_charge': 0,
            }
            
        self.multiframe_buffer = {
            '0x19F212FE': MultiFramePacket(),
            '0x19F201FE': MultiFramePacket(),
            '0x19F805FE': MultiFramePacket(),
        }

        self.nmea2k_dbc = cantools.database.load_file("./nmea2k.dbc", database_format='dbc', cache_dir='dbccache')
        
        self.last_sog_update = None
        self.last_energy_update = None
        self.last_rpm_update = None
        self.last_nvm_update = None
        self.above_75_soc = None
        self.below_50_soc = None
        self.fix_good = False

        self.config = configparser.ConfigParser()
        self.load_nvm()

    def load_nvm(self):
        inifile = self.config.read(NAME.lower()+'.nvm')

        if len(inifile) == 0:
            self.config[NAME] = {'batt_cycles': '0', 'total_distance': '0.0', 'total_motor_hours': '0.0'}
            self.persist_nvm()
            inifile = self.config.read(NAME.lower()+'.nvm')

        self.data['battCycles'] = int(self.config[NAME]['batt_cycles'])
        self.data['totalDistance'] = float(self.config[NAME]['total_distance'])
        self.data['totalMotorHours'] = float(self.config[NAME]['total_motor_hours'])

    def persist_nvm(self):
        with open(NAME.lower()+'.nvm', 'w') as configfile:
            self.config.write(configfile)
            configfile.close()

    def update_nvm(self):
        self.config[NAME]['total_distance'] = str(self.data['totalDistance'])
        self.config[NAME]['total_motor_hours'] = str(self.data['totalMotorHours'])
        self.config[NAME]['batt_cycles'] = str(self.data['battCycles'])
        
        self.persist_nvm()

    def get_source_address(self, can_id):
        return can_id & 0xFF

    def get_pgn(self, can_id):
        return (can_id >> 8) & 0x3FFFF

    def get_priority(self, can_id):
        return (can_id >> 26) & 0x7

    def parse_can_message(self, msg):
        # Engine Parmeters Rapid Update
        if self.get_pgn(msg.arbitration_id) == 0x1F200:
            try:
                frame = self.nmea2k_dbc.decode_message(0x19F200FE, msg.data, decode_choices=True, scaling=True)

                # Only handle the first engine instance for now
                if frame["EngineInstance"] != 'Single Engine or Dual Engine Port':
                    return

                self.data['rpm'] = frame["EngineSpeed"]

                if (self.data['rpm'] > 10):
                    date = datetime.utcnow() - datetime(1970, 1, 1)
                    ms = round((date.total_seconds())*1000)
                    if self.last_rpm_update != None:
                        self.data['totalMotorHours'] += ((ms - self.last_rpm_update) / 1000 / 3600)
                    self.last_rpm_update = ms
                else:
                    self.last_rpm_update = None
            except:
                self.handleExcept()

        # COG SOG Rapid Update
        if self.get_pgn(msg.arbitration_id) == 0x1F802:
            try:
                frame = self.nmea2k_dbc.decode_message(0x19F802FE, msg.data, decode_choices=True, scaling=True)

                if self.fix_good == False or frame["SpeedOverGround"] > 50: # 120mph
                    return

                self.data['sog'] = frame["SpeedOverGround"] / 0.5144   # m/s to Knots
                
                date = datetime.utcnow() - datetime(1970, 1, 1)
                ms = round((date.total_seconds())*1000)
                if self.last_sog_update != None:
                    self.data['tripDuration'] += ((ms - self.last_sog_update) / 1000)
                    meters = frame["SpeedOverGround"] * (ms - self.last_sog_update) / 1000
                    self.data['tripDistance'] += (meters * 0.000621371)
                    self.data['totalDistance'] += (meters * 0.000621371)
                self.last_sog_update = ms
                
                self.data['cog'] = frame["CourseOverGround"] / 0.01745 # rad to deg
                
                if self.data['cog'] > 315 and self.data['cog'] <= 45:
                    self.data['heading'] = "N"
                elif self.data['cog'] > 45 and self.data['cog'] <= 135:
                    self.data['heading'] = "E"
                elif self.data['cog'] > 135 and self.data['cog'] <= 270:
                    self.data['heading'] = "S"
                else:
                    self.data['heading'] = "W"
            except:
                self.handleExcept()
        
        # DC Detailed Status
        if self.get_pgn(msg.arbitration_id) == 0x1F212:
            self.multiframe_buffer['0x19F212FE'].handle_packet(msg)
            if self.multiframe_buffer['0x19F212FE'].finished:
                try:
                    frame = self.nmea2k_dbc.decode_message(0x19F212FE, self.multiframe_buffer['0x19F212FE'].payload, decode_choices=True, scaling=True)
                    
                    if frame['DCInstance'] != 0:
                        return

                    self.data['soc'] = frame["StateOfCharge"] # %
                    self.data['soh'] = frame["StateOfHealth"] # %
                    self.data['minsRemaining'] = frame['TimeRemaining'] # secs

                    if self.above_75_soc == None and self.data['soc'] > 75.0:
                        self.above_75_soc = True

                    if self.below_50_soc == None and self.data['soc'] < 50.0:
                        self.below_50_soc = True

                    # Count battery cycles
                    if self.below_50_soc == True and self.above_75_soc == True and self.data['soc'] > 75.0:
                        self.below_50_soc = False
                        self.data['battCycles'] += 1
                        self.persist_nvm()
                except:
                    self.handleExcept()
                    
                self.multiframe_buffer['0x19F212FE'].reset()
            
        # Engine Parameters Dynamic
        if self.get_pgn(msg.arbitration_id) == 0x1F201:
            self.multiframe_buffer['0x19F201FE'].handle_packet(msg)
            if self.multiframe_buffer['0x19F201FE'].finished:
                try:
                    frame = self.nmea2k_dbc.decode_message(0x19F201FE, self.multiframe_buffer['0x19F201FE'].payload, decode_choices=True, scaling=True)

                    # Only handle the first engine instance for now
                    if frame["EngineInstance"] != 'Single Engine or Dual Engine Port':
                        return

                    self.data['motorTemp'] = frame["EngineTemp"]-273 # K
                    self.data['motorTorquePct'] = frame["PercentEngineTorque"] # %
                    self.data['motorVoltage'] = frame["AlternatorPotential"] * 10.0
                    if frame["FuelPressure"] < 2000:
                        self.data['motorEnabled'] = 0
                    else:
                        self.data['motorEnabled'] = 1
                except:
                    self.handleExcept()
                    
                self.multiframe_buffer['0x19F201FE'].reset()
            
        # DC Voltage Current
        if self.get_pgn(msg.arbitration_id) == 0x1F307:
            try:
                frame = self.nmea2k_dbc.decode_message(0x19F307FE, msg.data, decode_choices=True, scaling=True)
                
                if frame['ConnectionNumber'] != 0:
                    pass

                self.data['packVoltage'] = frame["DCVoltage"] # V
                self.data['packCurrent'] = frame["DCCurrent"] # A
                self.data['power'] = self.data['packVoltage'] * self.data['packCurrent'] / 1000.0 # kW
                
                date = datetime.utcnow() - datetime(1970, 1, 1)
                ms = round((date.total_seconds())*1000)
                if self.last_energy_update != None:
                    power_used = self.data['power'] * (ms - self.last_energy_update) / 1000 / 3600
                    self.data['energyUsed'] += power_used
                self.last_energy_update = ms
            except:
                self.handleExcept()
                
        # GNSS Position Data
        if self.get_pgn(msg.arbitration_id) == 0x1F805: 
            self.multiframe_buffer['0x19F805FE'].handle_packet(msg)
            if self.multiframe_buffer['0x19F805FE'].finished:
                try:
                    frame = self.nmea2k_dbc.decode_message(0x19F805FE, self.multiframe_buffer['0x19F805FE'].payload, decode_choices=True, scaling=True)

                    #print("Integrity: "+str(frame["Integrity"]))
                    #print("Method: "+str(frame["MethodGNSS"]))

                    if frame["Latitude"] <= 360 and frame["Longitude"] <= 360:
                        self.fix_good = True
                    else:
                        return

                    days = frame["PositionDate"] # Since 1970
                    seconds = frame["PositionTime"]
                    timestamp = (days * 3600 * 24) + seconds
                    dt = datetime.fromtimestamp(timestamp)
                    self.data['date'] = dt.strftime("%Y/%m/%d")
                    self.data['time'] = dt.strftime("%H:%M:%S")
                except:
                    self.handleExcept()

                self.multiframe_buffer['0x19F805FE'].reset()

        # Battery Status
        if self.get_pgn(msg.arbitration_id) == 0x1F214:
            try:
                frame = self.nmea2k_dbc.decode_message(0x19F214FE, msg.data, decode_choices=True, scaling=True)

                # Only handle the first battery instance for now
                if frame["BatteryInstance"] != 0:
                    return

                self.data['packTemp'] = frame["BatteryCaseTemperature"] - 273
            except:
                self.handleExcept()

        # Transmission Parameters Dynamic
        if self.get_pgn(msg.arbitration_id) == 0x1F205:
            try:
                frame = self.nmea2k_dbc.decode_message(0x19F205FE, msg.data, decode_choices=True, scaling=True)

                # Only handle the first trans instance for now
                if frame["TransmissionInstance"] != "Single Engine or Dual Engine Port":
                    return

                self.data['gear'] = str(frame["TransmissionGear"])
            except:
                self.handleExcept()

        # switches
        if self.get_pgn(msg.arbitration_id) == 0x1F20D:
            try:
                frame = self.nmea2k_dbc.decode_message(0x19F20DFE, msg.data, decode_choices=True, scaling=True)
                    
                if frame["Status1"] == 'On':
                    self.data['state_sleep'] = 0
                    self.data['state_acc'] = 1
                    self.data['state_ign'] = 0
                    self.data['state_run'] = 0
                    self.data['state_charge'] = 0
                elif frame["Status2"] == 'On':
                    self.data['state_sleep'] = 0
                    self.data['state_acc'] = 0
                    self.data['state_ign'] = 1
                    self.data['state_run'] = 0
                    self.data['state_charge'] = 0
                elif frame["Status3"] == 'On':
                    self.data['state_sleep'] = 0
                    self.data['state_acc'] = 0
                    self.data['state_ign'] = 0
                    self.data['state_run'] = 1
                    self.data['state_charge'] = 0
                elif frame["Status4"] == 'On':
                    self.data['state_sleep'] = 0
                    self.data['state_acc'] = 0
                    self.data['state_ign'] = 0
                    self.data['state_run'] = 0
                    self.data['state_charge'] = 1
                else:
                    self.data['state_sleep'] = 1
                    self.data['state_acc'] = 0
                    self.data['state_ign'] = 0
                    self.data['state_run'] = 0
                    self.data['state_charge'] = 0
            except:
                self.handleExcept()

        date = datetime.utcnow() - datetime(1970, 1, 1)
        ms = round((date.total_seconds())*1000)
        if self.last_nvm_update != None:
            if (ms - self.last_nvm_update) / 1000 > 60:
                self.update_nvm()
                self.persist_nvm()
                self.last_nvm_update = ms
        else:
            self.last_nvm_update = ms

    async def onehelm_request(self, websocket, path):
        with can.Bus(
            interface="socketcan", channel="can0", bitrate=250000
        ) as bus:            
            while True:
                msg = bus.recv(0.2)
                if msg != None:
                    self.parse_can_message(msg)

                self.data['nmea2000_timeout'] = 0
                date = datetime.utcnow() - datetime(1970, 1, 1)
                ms = round((date.total_seconds())*1000)
                if self.last_rpm_update != None:
                    if ((ms - self.last_rpm_update) / 1000) > 1.5:
                        self.data['nmea2000_timeout'] = 1

                json_string = json.dumps(self.data)
                try:
                    await websocket.send(json_string)
                except websockets.exceptions.ConnectionClosedError:
                    print("Websocket closed")
                    self.handleExcept()
                    break


    def start_server(self, loop):
        websocket_server = websockets.serve(self.onehelm_request, None, 8080)
        loop.run_until_complete(websocket_server)

    def handleExcept(self):
        traceback.print_exc()
        
class MultiFramePacket():
    def __init__(self):
        self.payload = []
        self.payload_len = 0
        self.identifier = 0
        self.last_seq = 0
        self.started = False
        self.finished = False
        
    def handle_packet(self, msg):
        # sequence number within multiframe
        seq = msg.data[0] & 0x0F 
        
        if seq == 0:
            self.started = True
            self.payload_len = msg.data[1]
            self.identifier = msg.arbitration_id
            self.last_seq = 0
            
            self.payload += msg.data[2:8]
        else:
            if self.started == False:
                # The first frame was never received
                return
            
            if (self.last_seq + 1) != seq:
                # This is not the sequence number we expected
                return
                
            if self.identifier != msg.arbitration_id:
                # This is not the same sender we were handling
                return
                
            self.payload += msg.data[1:]

            self.last_seq = seq
            
            if len(self.payload) >= self.payload_len:
                self.finished = True
                
    def reset(self):
        self.payload.clear()
        self.started = False
        self.finished = False

def get_ip_address(ifname):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        return socket.inet_ntoa(fcntl.ioctl(s.fileno(),0x8915,struct.pack('256s', bytes(ifname[:15], 'utf-8')))[20:24])
    except:
        return None

if __name__ == '__main__':
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        print("Waiting for IP...")
        while True:
            ip = get_ip_address("eth0")
            if ip == None:
                pass
            elif "172" in ip or "192" in ip:
                print(ip)
                break
            time.sleep(1)


        server = NMEA2KServer()
        server.start_server(loop)

        loop.run_forever()
    except KeyboardInterrupt:
        pass
