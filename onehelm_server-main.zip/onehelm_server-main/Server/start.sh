#!/bin/bash

cd /home/photon/Server
/usr/bin/python nmea2000_server.py 2>&1 >> server.log
