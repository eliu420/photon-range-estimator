# Photon OneHelm Dash

OneHelm project for Photon Marine to display a custom dash on Garmin ChartPlotter MFDs.


## Dash App

The dash is implemented as a web app created with the Flutter framework. The Garmin MFDs use Webkit to render any HTML/JS based web content on their screens. Websockets can be used to fetch data from a server on the boat's NMEA2000 network.

To build the web app:
```
flutter build web --web-renderer=html --release

The release files can be found in the build/web folder. 
Note: needed to move the images from the assets/assets folder to the root assets folder. 

Navigate to /build/web/

To run and test:
flutter run -d chrome
(you may need to change resolution of your chrome window for proper viewing.)

If issues use flutter doctor to find out any flutter dependencies you may be missing.
```


Version info
- AndroidStudio: 2021.3.1 Patch 1
- Dart: 2.18.2
- Flutter: 3.3.4

## Linux Server

An embedded Linux server is responsible for hosting a service that gathers data from the NMEA2000 CAN bus and broadcasts the interpreted data over a websocket established from the Flutter App running on the display. The Linux server needs a CAN bus adapter to connect to the NMEA2000 bus and an Ethernet connection to the display.

### CAN Interface
Option 1) Use a PCAN USB-CAN adapter
Option 2) Use an MCP2515 CAN tranceiver

MCP2515 overlay added to /boot/config.txt
```
dtoverlay=mcp2515-can0,oscillator=16000000,interrupt=25
```

Copy can0 to /etc/network/interfaces.d/ to enable the can0 inteface on boot.

Copy onehelm.service to /etc/avahi/services to configure the ZeroConf system allowing the Garmin MFD to find the Server IP.

Copy nmea2000_server.service to /etc/systemd/system/ to start the Python websocket server on boot.
```
systemctl daemon-reload
systemctl enable nmea2000_server.service
```

Copy the Server folder to the photon home directory.

Install python modules
```
sudo pip install websockets python-can cantools
```

Install apache
```
sudo install apache2
```

wget http://www.uugear.com/repo/Zero2GoOmini/installZero2Go.sh

/etc/dhcpcd.conf # todo: settings

